require('dotenv').config();
const config=require('../backend/config/config');
const http=require('http');
const https=require('https');
const {URL}=require('url');
const base=process.env.BACKEND_URL||`http://127.0.0.1:${config.port}`;
const secret=process.env.AGENT_SECRET||config.agentSecret;
let stopped=false;
function request(path,body){return new Promise((resolve,reject)=>{const u=new URL(path,base),lib=u.protocol==='https:'?https:http;const data=JSON.stringify(body||{});const req=lib.request(u,{method:'POST',headers:{'content-type':'application/json','content-length':Buffer.byteLength(data),'x-agent-secret':secret}},res=>{let raw='';res.setEncoding('utf8');res.on('data',c=>raw+=c);res.on('end',()=>{if(res.statusCode<200||res.statusCode>=300)return reject(new Error(`HTTP_${res.statusCode}`));try{resolve(JSON.parse(raw))}catch{resolve({})}})});req.setTimeout(5000,()=>req.destroy(new Error('REQUEST_TIMEOUT')));req.on('error',reject);req.end(data)})}
async function heartbeat(){if(stopped)return;try{await request('/api/agent/heartbeat',{serverId:process.env.VIRTUALHERE_SERVER_ID||null,agentId:process.env.AGENT_ID||'sheik-gsm-agent',status:'AGENT_ONLINE',capabilities:{virtualHereCli:!!process.env.VIRTUALHERE_CLIENT_BIN},note:process.env.VIRTUALHERE_CLIENT_BIN?'CLI path configured; client API commands must be verified on this host':'VIRTUALHERE_CLIENT_BIN not configured'})}catch(e){console.error('[Agent] heartbeat failed:',e.message)}}
console.log('[Sheik GSM Agent]');console.log('Backend:',base);console.log('Agent secret configured:',Boolean(secret&&secret!=='CHANGE_ME'));console.log('VirtualHere client binary:',process.env.VIRTUALHERE_CLIENT_BIN||'not configured');
heartbeat();const timer=setInterval(heartbeat,15000);process.on('SIGINT',()=>{stopped=true;clearInterval(timer);process.exit(0)});process.on('SIGTERM',()=>{stopped=true;clearInterval(timer);process.exit(0)});
