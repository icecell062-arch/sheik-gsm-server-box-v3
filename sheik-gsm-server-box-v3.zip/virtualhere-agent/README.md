# Agente SHEIK GSM SERVER BOX

Execute este agente no computador autorizado que possui o cliente VirtualHere e as ferramentas GSM. A API hospedada no Render não tem acesso direto às portas USB desse computador.

1. Instale Node.js e as dependências do projeto (`npm install`).
2. Configure `BACKEND_URL` para a URL HTTPS da API.
3. Configure `AGENT_SECRET` com o mesmo segredo da API.
4. Configure `AGENT_ID` e, se aplicável, `VIRTUALHERE_SERVER_ID`.
5. `VIRTUALHERE_CLIENT_BIN` pode apontar para o executável oficial do cliente VirtualHere, mas esta versão do agente ainda não executa comandos de uso/liberação de dispositivos. A presença do caminho não comprova conectividade.
6. Inicie com `npm run agent` e confirme os logs de heartbeat.

**Limitação importante:** este agente envia heartbeat autenticado. O controle real de dispositivos (LIST/USE/UNUSE) ainda precisa ser implementado e validado contra a versão exata do VirtualHere instalada antes de liberar sessões para clientes. A API bloqueia o início da sessão quando não consegue confirmar a operação real.
