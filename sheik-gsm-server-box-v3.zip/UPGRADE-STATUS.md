# Estado do upgrade V3

## Implementado nesta entrega
- Painel administrativo com dashboard de contagens reais.
- CRUD de boxes com edição, status e arquivamento seguro se houver tokens históricos.
- Listagem de tokens, geração, cópia manual do código exibido e revogação.
- Cadastro e remoção de servidores/dispositivos VirtualHere.
- Listagem de sessões e ação administrativa de encerramento.
- Diagnóstico do Telegram por `getMe` quando o bot está ativo.
- Migração automática de senha legada SHA-256 para scrypt após login bem-sucedido.
- Validações de duração de token e de campos de cadastro.
- Agente com heartbeat autenticado e instruções de instalação.
- README e `.env.example` atualizados.

## Ainda pendente — não considerar produção pronta
- Controle real VirtualHere para listar, conectar/usar e liberar o dispositivo através do cliente oficial instalado no agente. A API detecta acessibilidade TCP, mas isso não comprova disponibilidade USB.
- Agente ainda não executa o ciclo de comandos do VirtualHere; portanto, por segurança, a API recusa iniciar e finalizar uma sessão enquanto não houver confirmação real.
- Teste integrado com bot Telegram real, servidor VirtualHere real e box física não foi possível neste ambiente.
- Não foi possível concluir `npm install` no ambiente de construção (timeout); foram executadas verificações de sintaxe de todos os arquivos JavaScript, não testes de execução completos.
- Para uso no Render, configure disco persistente para SQLite ou escolha banco gerenciado; o sistema de arquivos efêmero não deve ser usado como armazenamento definitivo.

A recusa de iniciar/liberar sessão sem confirmação real é intencional: evita declarar uma conexão falsa ou disponibilizar uma box que ainda esteja ocupada.
