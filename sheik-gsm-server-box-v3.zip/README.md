# SHEIK GSM SERVER BOX V3 — base de upgrade

Projeto Node.js/Express + SQLite, com painel administrativo, painel do cliente por token, bot Telegram e adaptador VirtualHere.

## Instalação local

1. Instale Node.js 20 ou superior.
2. Execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Defina `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `JWT_SECRET` e `AGENT_SECRET` com valores próprios e fortes. Não publique o `.env`.
5. Execute `npm start`.
6. Abra `http://localhost:3000` e entre em `/login.html` com o administrador configurado.
7. Para o bot, configure `TELEGRAM_BOT_TOKEN`. O processo principal inicia o bot automaticamente; não execute `npm run bot` ao mesmo tempo, pois isso cria duas instâncias de polling.
8. Para o agente, consulte `virtualhere-agent/README.md` e execute-o na máquina autorizada que possui o cliente VirtualHere.

## Render

Publique a API como Web Service Node. Configure as variáveis de ambiente na área Environment. SQLite no disco efêmero de um serviço comum pode perder dados em redeploy/restart; use um disco persistente do Render e defina `DATABASE_PATH` para um caminho dentro desse disco, ou migre para banco gerenciado antes de produção. O agente deve rodar no computador que tem acesso ao VirtualHere, não no serviço web do Render.

## Estado real das integrações

- CRUD de boxes, tokens, servidores/dispositivos cadastrados e listagem/encerramento administrativo de sessões: implementado na API/painel.
- Telegram: usa o bot oficial por `node-telegram-bot-api`; o painel testa `getMe` quando o bot foi iniciado e a variável está configurada.
- VirtualHere: o diagnóstico TCP distingue servidor inacessível de porta TCP alcançável. Isso **não** confirma que um dispositivo USB está listado ou conectado.
- O adaptador ainda não implementa os comandos oficiais de cliente para descobrir, usar e liberar um dispositivo. Por segurança, iniciar/encerrar sessões fica bloqueado enquanto essa operação real não for confirmada. Consulte a API oficial do cliente: https://www.virtualhere.com/client_api
- O agente atual envia heartbeat autenticado, mas ainda não executa controle de dispositivos.

## Segurança e teste

Não use `CHANGE_ME` em produção. Use HTTPS, segredos fortes, firewall e acesso administrativo restrito. Antes de produção, valide as operações de conexão/liberação com o VirtualHere instalado, configure armazenamento persistente e execute testes com bot/servidor reais. Não use dados fictícios para declarar serviços online.
