const {startTelegram}=require("../backend/services/telegramService");
startTelegram();
setInterval(()=>{},1<<30);
