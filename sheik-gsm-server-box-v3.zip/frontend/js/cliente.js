(function(){
const list=document.getElementById("boxList"),search=document.getElementById("boxSearch"),filter=document.getElementById("boxFilter");
let boxes=[],active=null,timer=null,validated=null;

async function load(){
 try{boxes=await API.get("/boxes");render()}catch(e){toast("Não foi possível carregar as boxes.","error")}
}
function render(){
 const q=search.value.toLowerCase(),f=filter.value;
 const data=boxes.filter(b=>(!q||(b.name+" "+(b.description||"")).toLowerCase().includes(q))&&(f==="ALL"||b.status===f));
 list.innerHTML=data.map(b=>`<div class="box-card"><div><div class="box-name">⚙ ${esc(b.name)}</div><div class="box-desc">${esc(b.description||"VirtualHere")}</div></div><span class="box-state ${b.status==="AVAILABLE"?"available":b.status==="BUSY"?"busy":"offline"}">● ${esc(b.status)}</span><button class="btn ${b.status==="AVAILABLE"?"btn-primary":"btn-ghost"} small" ${b.status!=="AVAILABLE"||!validated?"disabled":""} data-id="${b.id}">⚡ CONECTAR</button></div>`).join("")||`<div class="empty">Nenhuma box encontrada.</div>`;
 list.querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>connect(b.dataset.id));
}
document.getElementById("validateBtn").onclick=async()=>{
 try{
   const r=await API.post("/tokens/validate",{token:document.getElementById("tokenInput").value.trim()});
   validated=r.token;
   toast("Token válido. Escolha a box.");
   render();
 }catch(e){validated=null;toast("Token inválido ou expirado.","error");render()}
};
async function connect(boxId){
 if(!validated)return toast("Valide o token primeiro.","warning");
 try{
   active=await API.post("/sessions/connect",{token:validated.code,boxId});
   document.getElementById("connectionDot").textContent="● CONECTADO";
   document.getElementById("connectionDot").className="status online";
   document.getElementById("connectionTitle").textContent="SESSÃO ATIVA";
   document.getElementById("activeInfo").classList.remove("hidden");
   const b=boxes.find(x=>x.id===boxId);
   document.getElementById("activeToken").textContent=validated.code;
   document.getElementById("activeBox").textContent=b?.name||boxId;
   document.getElementById("activeExpiry").textContent=fmtDate(active.expiresAt);
   document.getElementById("tokenInput").disabled=true;
   document.getElementById("validateBtn").disabled=true;
   startTimer();toast("Sessão autorizada pelo servidor.");
   await load();
 }catch(e){toast(e.message==="VIRTUALHERE_ADAPTER_NOT_CONFIGURED"?"VirtualHere ainda não está configurado no adapter.":"Não foi possível conectar: "+e.message,"error")}
}
function startTimer(){clearInterval(timer);timer=setInterval(()=>{const left=active.expiresAt-Date.now();document.getElementById("timer").textContent=fmtTime(left);if(left<=0){clearInterval(timer);active=null;toast("Sessão expirada.","warning");location.reload()}},500)}
document.getElementById("endSessionBtn").onclick=async()=>{
 if(!active)return;
 if(!confirm("Encerrar a sessão?"))return;
 try{await API.post("/sessions/disconnect",{sessionId:active.id});location.reload()}catch(e){toast("Erro ao encerrar sessão.","error")}
};
search.oninput=render;filter.onchange=render;load();
})();