document.getElementById("loginForm").addEventListener("submit",async e=>{
 e.preventDefault();const err=document.getElementById("error");err.classList.add("hidden");
 try{const r=await API.post("/admin/login",{username:username.value,password:password.value});sessionStorage.setItem("adminToken",r.token);location.href="/admin.html"}
 catch(x){err.textContent="Acesso administrativo inválido.";err.classList.remove("hidden")}
});