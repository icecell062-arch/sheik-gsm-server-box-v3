const API = {
  async request(path, options={}) {
    const headers={"Content-Type":"application/json",...(options.headers||{})};
    const token=sessionStorage.getItem("adminToken");
    if(token) headers.Authorization=`Bearer ${token}`;
    const res=await fetch(`/api${path}`,{...options,headers});
    const data=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(data.error||`HTTP_${res.status}`);
    return data;
  },
  get(path){return this.request(path)},
  post(path,body){return this.request(path,{method:"POST",body:JSON.stringify(body)})},
  put(path,body){return this.request(path,{method:"PUT",body:JSON.stringify(body)})},
  delete(path){return this.request(path,{method:"DELETE"})}
};
function toast(message,type="success"){const root=document.getElementById("toastRoot");if(!root)return;const e=document.createElement("div");e.className=`toast ${type}`;e.textContent=message;root.appendChild(e);setTimeout(()=>e.remove(),3500)}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function fmtDate(ts){return new Date(ts).toLocaleString("pt-BR")}
function fmtTime(ms){ms=Math.max(0,ms);let s=Math.floor(ms/1000),h=Math.floor(s/3600);s%=3600;let m=Math.floor(s/60);s%=60;return (h?String(h).padStart(2,"0")+":":"")+String(m).padStart(2,"0")+":"+String(s).padStart(2,"0")}
