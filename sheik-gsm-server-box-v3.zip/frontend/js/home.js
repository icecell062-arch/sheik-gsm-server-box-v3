(async function(){
document.getElementById("year").textContent=new Date().getFullYear();
try{
 const boxes=await API.get("/boxes");
 document.getElementById("boxCount").textContent=boxes.length;
 document.getElementById("availableCount").textContent=boxes.filter(b=>b.status==="AVAILABLE").length;
 document.getElementById("sessionCount").textContent=boxes.filter(b=>b.status==="BUSY").length;
 document.getElementById("homeBoxes").innerHTML=boxes.slice(0,8).map(b=>`<article class="feature"><b>⚙ ${esc(b.name)}</b><p>${esc(b.description||"VirtualHere")}</p><span class="status ${b.status==="AVAILABLE"?"online":"warn"}">● ${esc(b.status)}</span></article>`).join("");
}catch(e){console.error(e)}
})();