const express=require("express");
const {requireAgent}=require("../middleware/auth");
const {db}=require("../database/database");
const router=express.Router();

router.post("/heartbeat",requireAgent,(req,res)=>{
  const {serverId}=req.body||{};
  if(serverId) db.prepare("UPDATE virtualhere_servers SET status='ONLINE',last_seen=? WHERE id=?").run(Date.now(),serverId);
  res.json({ok:true});
});

router.post("/status",requireAgent,(req,res)=>{
  const {serverId,status}=req.body||{};
  if(serverId) db.prepare("UPDATE virtualhere_servers SET status=?,last_seen=? WHERE id=?").run(status||"OFFLINE",Date.now(),serverId);
  res.json({ok:true});
});
module.exports=router;
