const express = require("express");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const {db} = require("../database/database");
const config = require("../config/config");
const router = express.Router();

router.post("/login",(req,res)=>{
  const {username,password}=req.body||{};
  const a=db.prepare("SELECT * FROM admins WHERE username=?").get(username);
  if(!a) return res.status(401).json({error:"INVALID_CREDENTIALS"});
  const stored=String(a.password_hash||"");
  let valid=false;
  if(stored.startsWith("scrypt:")){const parts=stored.split(":");if(parts.length===3){const expected=Buffer.from(parts[2],"hex");const actual=crypto.scryptSync(String(password||""),parts[1],expected.length);valid=expected.length===actual.length&&crypto.timingSafeEqual(expected,actual)}}
  else {const legacy=crypto.createHash("sha256").update(String(password||"")).digest("hex");valid=legacy===stored;if(valid){const {hashPassword}=require("../database/database");db.prepare("UPDATE admins SET password_hash=? WHERE id=?").run(hashPassword(String(password||"")),a.id)}}
  if(!valid) return res.status(401).json({error:"INVALID_CREDENTIALS"});
  const token=jwt.sign({sub:a.id,username:a.username,role:"admin"},config.jwtSecret,{expiresIn:"8h"});
  res.json({token});
});
module.exports=router;
