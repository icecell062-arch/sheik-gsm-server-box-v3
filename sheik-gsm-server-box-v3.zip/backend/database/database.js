const Database = require("better-sqlite3");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const config = require("../config/config");

const dir = path.dirname(config.dbPath);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(config.dbPath);
db.pragma("journal_mode = WAL");

const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
db.exec(schema);

function uid() { return crypto.randomUUID(); }
function hashPassword(password) { const salt=crypto.randomBytes(16).toString("hex"); const hash=crypto.scryptSync(String(password),salt,64).toString("hex"); return `scrypt:${salt}:${hash}`; }

function seed() {
  const now = Date.now();

  const admin = db.prepare("SELECT id FROM admins WHERE username=?").get(config.adminUsername);
  if (!admin) {
    const cryptoHash = hashPassword(config.adminPassword);
    db.prepare("INSERT INTO admins(id,username,password_hash,created_at) VALUES(?,?,?,?)")
      .run(uid(), config.adminUsername, cryptoHash, now);
  }

  const boxCount = db.prepare("SELECT COUNT(*) c FROM boxes").get().c;
  if (!boxCount) {
    const insert = db.prepare(`INSERT INTO boxes
      (id,name,description,status,price,virtualhere_server_id,virtualhere_device_id,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?)`);
    const names = [
      ["OCTOPLUS 4","VirtualHere / Service Tool"],
      ["OCTOPLUS 5","VirtualHere / Service Tool"],
      ["OCTOPLUS 6","VirtualHere / Service Tool"],
      ["SIGMA 2","VirtualHere / Service Tool"],
      ["SIGMA 3","VirtualHere / Service Tool"],
      ["Z3X 4","VirtualHere / Service Tool"],
      ["Z3X 5","VirtualHere / Service Tool"],
      ["UMT 6","VirtualHere / Service Tool"],
      ["MRT","VirtualHere / Service Tool"],
      ["EFT PRO","VirtualHere / Service Tool"],
      ["HYDRA","VirtualHere / Service Tool"],
      ["CHIMERA","VirtualHere / Service Tool"]
    ];
    const tx = db.transaction(() => {
      for (const [name, desc] of names) {
        insert.run(uid(), name, desc, "AVAILABLE", 7.99, null, null, now, now);
      }
    });
    tx();
  }

  const planCount = db.prepare("SELECT COUNT(*) c FROM plans").get().c;
  if (!planCount) {
    const insert = db.prepare("INSERT INTO plans(id,name,duration_minutes,price,status,created_at) VALUES(?,?,?,?,?,?)");
    [
      ["Básico",30,4.99],["Profissional",60,7.99],["Premium",120,12.99],["Diário",1440,39.90]
    ].forEach(([n,d,p]) => insert.run(uid(),n,d,p,"ACTIVE",now));
  }
}
seed();

module.exports = { db, uid, hashPassword };
