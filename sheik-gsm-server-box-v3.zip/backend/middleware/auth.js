const jwt = require("jsonwebtoken");
const config = require("../config/config");

function requireAdmin(req,res,next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({error:"AUTH_REQUIRED"});
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    if (payload.role !== "admin") return res.status(403).json({error:"FORBIDDEN"});
    req.admin = payload;
    next();
  } catch {
    res.status(401).json({error:"INVALID_TOKEN"});
  }
}

function requireAgent(req,res,next) {
  const secret = req.headers["x-agent-secret"];
  if (!secret || secret !== config.agentSecret) return res.status(401).json({error:"AGENT_UNAUTHORIZED"});
  next();
}

module.exports = { requireAdmin, requireAgent };
