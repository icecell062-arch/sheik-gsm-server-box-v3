const express=require("express");
const cors=require("cors");
const rateLimit=require("express-rate-limit");
const path=require("path");
const config=require("./config/config");
const {db}=require("./database/database");
const sessionService=require("./services/sessionService");
const telegramService=require("./services/telegramService");

const app=express();
app.use(cors({origin:true}));
app.use(express.json({limit:"32kb"}));
app.use(rateLimit({windowMs:60000,max:240,standardHeaders:true,legacyHeaders:false}));

app.use("/api/admin",require("./routes/auth"));
app.use("/api/admin",require("./routes/admin"));
app.use("/api/boxes",require("./routes/boxes"));
app.use("/api/tokens",require("./routes/tokens"));
app.use("/api/sessions",require("./routes/sessions"));
app.use("/api/virtualhere",require("./routes/virtualhere"));
app.use("/api/telegram",require("./routes/telegram"));
app.use("/api/agent",require("./routes/agent"));

app.use(express.static(path.join(__dirname,"../frontend")));

app.get("/api/health",(req,res)=>res.json({ok:true,time:Date.now()}));

setInterval(async()=>{
  try{
    const rows=sessionService.expireSessions();
    for(const s of rows){
      await sessionService.disconnect(s.id,"EXPIRED");
    }
    db.prepare("UPDATE tokens SET status='EXPIRED' WHERE status='ACTIVE' AND expires_at<=?").run(Date.now());
  }catch(e){console.error("[session-cleaner]",e.message)}
},5000);

app.listen(config.port,()=>{
  console.log(`Sheik GSM Server Box: http://localhost:${config.port}`);
  telegramService.startTelegram();
});
