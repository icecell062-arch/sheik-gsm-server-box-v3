const crypto = require("crypto");
const {db, uid} = require("../database/database");

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const part = n => Array.from({length:n},()=>chars[crypto.randomInt(chars.length)]).join("");
  return `SGSM-${part(4)}-${part(4)}`;
}

function createToken({boxId,durationMinutes,telegramUserId=null}) {
  const box = db.prepare("SELECT * FROM boxes WHERE id=?").get(boxId);
  if (!box) throw new Error("BOX_NOT_FOUND");
  if (!Number.isInteger(Number(durationMinutes)) || Number(durationMinutes)<1 || Number(durationMinutes)>10080) throw new Error("INVALID_DURATION");
  if (box.status !== "AVAILABLE") throw new Error("BOX_UNAVAILABLE");

  let code;
  do { code = generateCode(); } while (db.prepare("SELECT id FROM tokens WHERE code=?").get(code));

  const now = Date.now();
  const token = {
    id: uid(), code, boxId, telegramUserId,
    status: "ACTIVE",
    durationMinutes,
    createdAt: now,
    expiresAt: now + durationMinutes*60000
  };

  db.prepare(`INSERT INTO tokens
    (id,code,box_id,telegram_user_id,status,duration_minutes,created_at,expires_at)
    VALUES(?,?,?,?,?,?,?,?)`)
    .run(token.id,token.code,token.boxId,token.telegramUserId,token.status,
         token.durationMinutes,token.createdAt,token.expiresAt);

  return token;
}

function findValid(code) {
  const t = db.prepare("SELECT * FROM tokens WHERE code=?").get(String(code||"").trim().toUpperCase());
  if (!t) return null;
  if (t.status !== "ACTIVE" || t.expires_at <= Date.now()) {
    if (t.status === "ACTIVE") db.prepare("UPDATE tokens SET status='EXPIRED' WHERE id=?").run(t.id);
    return null;
  }
  return t;
}

module.exports = { createToken, findValid };
