const net=require('net');
const PROBE_TIMEOUT=2500;
function tcpProbe(server){return new Promise(resolve=>{if(!server||!server.host||!server.port)return resolve({ok:false,mode:'not-configured',error:'VIRTUALHERE_SERVER_NOT_CONFIGURED'});const socket=net.createConnection({host:server.host,port:Number(server.port)});let done=false;const finish=result=>{if(done)return;done=true;socket.destroy();resolve(result)};socket.setTimeout(PROBE_TIMEOUT);socket.once('connect',()=>finish({ok:false,mode:'tcp-reachable-adapter-required',tcpReachable:true,error:'VIRTUALHERE_TCP_REACHABLE_BUT_CLIENT_API_NOT_CONFIGURED',serverId:server.id,checkedAt:Date.now()}));socket.once('timeout',()=>finish({ok:false,mode:'offline',tcpReachable:false,error:'VIRTUALHERE_CONNECTION_TIMEOUT',serverId:server.id,checkedAt:Date.now()}));socket.once('error',()=>finish({ok:false,mode:'offline',tcpReachable:false,error:'VIRTUALHERE_CONNECTION_FAILED',serverId:server.id,checkedAt:Date.now()}))})}
class VirtualHereAdapter{
 async healthCheck(server){return tcpProbe(server)}
 async getServerStatus(server){return tcpProbe(server)}
 async listDevices(server){return {ok:false,mode:'adapter-required',devices:[],error:'VIRTUALHERE_CLIENT_API_NOT_CONFIGURED',serverId:server?.id}}
 async getDeviceStatus(server,device){return {ok:false,mode:'adapter-required',error:'VIRTUALHERE_CLIENT_API_NOT_CONFIGURED',serverId:server?.id,deviceId:device?.id}}
 async prepareSession({box,serverId,deviceId}){return {ok:false,mode:'adapter-required',error:!serverId||!deviceId?'VIRTUALHERE_SERVER_OR_DEVICE_NOT_CONFIGURED':'VIRTUALHERE_CLIENT_API_NOT_CONFIGURED',boxId:box.id,serverId,deviceId}}
 async releaseSession({box}){return {ok:false,mode:'adapter-required',error:'VIRTUALHERE_RELEASE_NOT_CONFIRMED',boxId:box.id}}
}
module.exports=new VirtualHereAdapter();
