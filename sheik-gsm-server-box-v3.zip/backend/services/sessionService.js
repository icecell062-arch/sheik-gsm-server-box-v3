const {db, uid} = require("../database/database");
const {findValid} = require("./tokenService");
const virtualHere = require("./virtualHereService");

async function connect({tokenCode,boxId}) {
  const token = findValid(tokenCode);
  if (!token) throw new Error("TOKEN_INVALID");
  if (token.box_id !== boxId) throw new Error("TOKEN_BOX_MISMATCH");

  const active = db.prepare("SELECT * FROM sessions WHERE status='ACTIVE'").get();
  if (active) throw new Error("ACTIVE_SESSION_EXISTS");

  const box = db.prepare("SELECT * FROM boxes WHERE id=?").get(boxId);
  if (!box || box.status !== "AVAILABLE") throw new Error("BOX_UNAVAILABLE");

  const result = await virtualHere.prepareSession({
    box,
    serverId: box.virtualhere_server_id,
    deviceId: box.virtualhere_device_id
  });

  if (!result.ok) throw new Error(result.error || "VIRTUALHERE_UNAVAILABLE");

  const now = Date.now();
  const expiresAt = Math.min(now + token.duration_minutes*60000, token.expires_at);
  const sessionId = uid();

  db.prepare(`INSERT INTO sessions
    (id,token_id,box_id,telegram_user_id,status,started_at,expires_at)
    VALUES(?,?,?,?,?,?,?)`)
    .run(sessionId, token.id, boxId, token.telegram_user_id, "ACTIVE", now, expiresAt);

  db.prepare("UPDATE tokens SET status='USED',used_at=?,session_id=? WHERE id=?")
    .run(now,sessionId,token.id);

  db.prepare("UPDATE boxes SET status='BUSY',updated_at=? WHERE id=?")
    .run(now,boxId);

  db.prepare("INSERT INTO logs(id,actor,action,box_id,status,created_at,details) VALUES(?,?,?,?,?,?,?)")
    .run(uid(), token.telegram_user_id ? `telegram:${token.telegram_user_id}` : "token",
         "SESSION_CONNECTED",boxId,"OK",now,JSON.stringify(result));

  return {id:sessionId,boxId,status:"ACTIVE",startedAt:now,expiresAt};
}

async function disconnect(sessionId, reason="USER") {
  const s = db.prepare("SELECT * FROM sessions WHERE id=? AND status='ACTIVE'").get(sessionId);
  if (!s) throw new Error("SESSION_NOT_FOUND");

  const box = db.prepare("SELECT * FROM boxes WHERE id=?").get(s.box_id);
  const release = await virtualHere.releaseSession({box});
  if (!release || !release.ok) throw new Error(release?.error || "VIRTUALHERE_RELEASE_NOT_CONFIRMED");

  const now = Date.now();
  db.prepare("UPDATE sessions SET status='ENDED',ended_at=? WHERE id=?").run(now,sessionId);
  db.prepare("UPDATE boxes SET status='AVAILABLE',updated_at=? WHERE id=?").run(now,s.box_id);

  db.prepare("INSERT INTO logs(id,actor,action,box_id,status,created_at,details) VALUES(?,?,?,?,?,?,?)")
    .run(uid(),"system","SESSION_DISCONNECTED",s.box_id,"OK",now,JSON.stringify({reason}));

  return {ok:true};
}

function expireSessions() {
  const rows = db.prepare("SELECT * FROM sessions WHERE status='ACTIVE' AND expires_at<=?").all(Date.now());
  return rows;
}

module.exports = {connect,disconnect,expireSessions};
