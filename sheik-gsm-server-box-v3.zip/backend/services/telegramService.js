const TelegramBot = require("node-telegram-bot-api");
const config = require("../config/config");
const {db} = require("../database/database");
const {createToken} = require("./tokenService");

let bot = null;

function startTelegram() {
  if (!config.telegramBotToken) {
    console.log("[Telegram] TELEGRAM_BOT_TOKEN não configurado; bot não iniciado.");
    return null;
  }

  bot = new TelegramBot(config.telegramBotToken,{polling:true});
  bot.on("polling_error", e => console.error("[Telegram polling]", e.message));
  bot.on("webhook_error", e => console.error("[Telegram webhook]", e.message));

  const mainMenu = {
    reply_markup:{inline_keyboard:[
      [{text:"🎫 GERAR TOKEN",callback_data:"token"}],
      [{text:"🖥 BOXES DISPONÍVEIS",callback_data:"boxes"}],
      [{text:"📡 MINHA SESSÃO",callback_data:"session"}],
      [{text:"❌ ENCERRAR SESSÃO",callback_data:"cancel"}]
    ]}
  };

  bot.onText(/\/start|\/menu|\/ajuda/, msg => {
    bot.sendMessage(msg.chat.id,"SHEIK GSM SERVER BOX\\n\\nEscolha uma opção:",mainMenu);
  });

  bot.onText(/\/boxes/, msg => sendBoxes(msg.chat.id));

  bot.onText(/\/token/, msg => {
    bot.sendMessage(msg.chat.id,"Escolha a duração:",{
      reply_markup:{inline_keyboard:[
        [{text:"15 MIN",callback_data:"dur:15"},{text:"30 MIN",callback_data:"dur:30"}],
        [{text:"1 HORA",callback_data:"dur:60"},{text:"2 HORAS",callback_data:"dur:120"}],
        [{text:"1 DIA",callback_data:"dur:1440"}]
      ]}
    });
  });

  bot.onText(/\/status|\/sessao/, msg => sendSession(msg.chat.id));
  bot.onText(/\/cancelar/, msg => bot.sendMessage(msg.chat.id,"Para encerrar, use o painel do cliente. Por segurança, o bot não encerra sessões de terceiros."));
  bot.on("message", msg => { if(msg.text && /^\/(start|menu|ajuda|boxes|token|status|sessao|cancelar)(@\w+)?$/.test(msg.text.trim())) return; });

  bot.on("callback_query", async q => {
    const chatId = q.message.chat.id;
    const data = q.data;
    try {
      if (data === "token") {
        return bot.sendMessage(chatId,"Escolha a duração:",{
          reply_markup:{inline_keyboard:[
            [{text:"15 MIN",callback_data:"dur:15"},{text:"30 MIN",callback_data:"dur:30"}],
            [{text:"1 HORA",callback_data:"dur:60"},{text:"2 HORAS",callback_data:"dur:120"}],
            [{text:"1 DIA",callback_data:"dur:1440"}]
          ]}
        });
      }
      if (data.startsWith("dur:")) {
        const duration = Number(data.split(":")[1]);
        await bot.answerCallbackQuery(q.id);
        const boxes = db.prepare("SELECT * FROM boxes WHERE status='AVAILABLE'").all();
        if (!boxes.length) return bot.sendMessage(chatId,"Nenhuma box disponível no momento.");
        return bot.sendMessage(chatId,"Escolha a box:",{
          reply_markup:{inline_keyboard:boxes.map(b=>[{text:`🖥 ${b.name}`,callback_data:`newtoken:${duration}:${b.id}`}])}
        });
      }
      if (data.startsWith("newtoken:")) {
        const [,duration,boxId] = data.split(":");
        const telegramUserId = String(q.from.id);
        const t = createToken({boxId,durationMinutes:Number(duration),telegramUserId});
        await bot.answerCallbackQuery(q.id);
        return bot.sendMessage(chatId,
          `🎫 TOKEN GERADO\\n\\n${t.code}\\n\\nBox: ${db.prepare("SELECT name FROM boxes WHERE id=?").get(boxId).name}\\nValidade: ${Number(duration)} minutos\\n\\nAbra o painel e cole o token.`
        );
      }
      if (data === "boxes") return sendBoxes(chatId);
      if (data === "session") return sendSession(chatId);
      if (data === "cancel") return bot.sendMessage(chatId,"Para encerrar uma sessão, use o botão ENCERRAR no painel.");
    } catch(e) {
      bot.sendMessage(chatId,"Não foi possível concluir a operação: "+e.message);
    }
  });

  console.log("[Telegram] bot iniciado.");
  return bot;
}

function sendBoxes(chatId) {
  const boxes = db.prepare("SELECT * FROM boxes").all();
  const text = boxes.map(b=>`• ${b.name} — ${b.status}`).join("\\n") || "Nenhuma box cadastrada.";
  return bot.sendMessage(chatId,"BOXES\\n\\n"+text);
}

function sendSession(chatId) {
  const s = db.prepare("SELECT * FROM sessions WHERE telegram_user_id=? AND status='ACTIVE' ORDER BY started_at DESC LIMIT 1").get(String(chatId));
  if (!s) return bot.sendMessage(chatId,"Nenhuma sessão ativa.");
  const box = db.prepare("SELECT name FROM boxes WHERE id=?").get(s.box_id);
  const left = Math.max(0,s.expires_at-Date.now());
  const mins = Math.floor(left/60000);
  return bot.sendMessage(chatId,`📡 SUA SESSÃO\\n\\nBOX: ${box?.name||"-"}\\nSTATUS: 🟢 ATIVA\\nTEMPO: ${mins} min`);
}

async function getTelegramStatus() {
  if (!config.telegramBotToken || !bot) return {configured:Boolean(config.telegramBotToken),running:false,lastContact:null,detail:config.telegramBotToken?"BOT_NOT_STARTED":"TELEGRAM_BOT_TOKEN_NOT_CONFIGURED"};
  try { const me=await bot.getMe(); return {configured:true,running:true,username:me.username||null,botId:me.id,lastContact:Date.now(),detail:"API_OK"}; } catch(e) { return {configured:true,running:false,lastContact:null,detail:"TELEGRAM_API_ERROR"}; }
}

function notifyTelegram(telegramUserId,text) {
  if (bot && telegramUserId) return bot.sendMessage(telegramUserId,text);
}

module.exports = {startTelegram,notifyTelegram,getTelegramStatus};
