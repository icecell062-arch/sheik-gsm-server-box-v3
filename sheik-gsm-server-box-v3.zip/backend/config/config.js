require("dotenv").config();

if (process.env.NODE_ENV === "production" && (!process.env.JWT_SECRET || process.env.JWT_SECRET === "CHANGE_ME" || !process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD === "CHANGE_ME" || !process.env.AGENT_SECRET || process.env.AGENT_SECRET === "CHANGE_ME")) {
  throw new Error("Configure JWT_SECRET, ADMIN_PASSWORD e AGENT_SECRET fortes antes de iniciar em produção.");
}

module.exports = {
  port: Number(process.env.PORT || 3000),
  dbPath: process.env.DATABASE_PATH || "./backend/database/sheikgsm.sqlite",
  jwtSecret: process.env.JWT_SECRET || "CHANGE_ME",
  adminUsername: process.env.ADMIN_USERNAME || "admin",
  adminPassword: process.env.ADMIN_PASSWORD || "CHANGE_ME",
  telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || "",
  publicClientUrl: process.env.PUBLIC_CLIENT_URL || "http://localhost:3000/cliente.html",
  agentSecret: process.env.AGENT_SECRET || "CHANGE_ME",
  virtualHereHost: process.env.VIRTUALHERE_HOST || "127.0.0.1",
  virtualHerePort: Number(process.env.VIRTUALHERE_PORT || 7575)
};
